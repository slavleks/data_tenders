import sympy
a, b =sympy.symbols('a b')
e=(a+b)**5
e.expand()
